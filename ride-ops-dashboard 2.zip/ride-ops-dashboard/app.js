// ============================================
// RIDE OPS DASHBOARD - Application Logic
// With Role-Based Access Control (RBAC)
// ============================================

let currentPage = 'dashboard';
let currentBookingType = 'ALL';
let selectedDispatchBooking = null;
let currentRole = 'ADMIN';
let currentUser = null;

// Role configurations
const ROLE_CONFIG = {
  ADMIN: { name: 'Quản trị viên', permissions: ['*'], pages: ['dashboard','users','routes','partners','bookings','fulfillment','intercity','wallets','refunds','promos','commissions','notifications','audit','monitoring'] },
  OPERATOR: { name: 'Điều hành', permissions: ['booking.view','booking.cancel','fulfillment.assign','wallet.view','refund.process','master.view','partner.view','driver.view'], pages: ['dashboard','routes','partners','bookings','fulfillment','wallets','refunds','promos','notifications','monitoring'] },
  AGENT: { name: 'Đại lý', permissions: ['booking.create','booking.view','customer.manage','wallet.view','driver.view','driver.manage'], pages: ['dashboard','bookings','intercity','partners','wallets'] },
  FINANCE: { name: 'Tài chính', permissions: ['wallet.view','wallet.adjust','refund.process','settlement.manage','report.view','commission.view','audit.view','booking.view','system.view'], pages: ['dashboard','bookings','wallets','refunds','commissions','audit','monitoring'] },
  VIEWER: { name: 'Người xem', permissions: ['booking.view','wallet.view','report.view','system.view'], pages: ['dashboard','bookings','wallets','monitoring'] }
};

const ROLE_USERS = {
  ADMIN: { id: 'USR001', name: 'Nguyễn Admin' },
  OPERATOR: { id: 'USR002', name: 'Trần Operator' },
  AGENT: { id: 'USR003', name: 'Lê Agent HCM' },
  FINANCE: { id: 'USR004', name: 'Phạm Finance' },
  VIEWER: { id: 'USR005', name: 'Võ Viewer' }
};

// ---- Permissions ----
function hasPermission(perm) {
  const config = ROLE_CONFIG[currentRole];
  if (!config) return false;
  if (config.permissions.includes('*')) return true;
  return config.permissions.includes(perm);
}

// ---- Role Switch ----
function switchRole(role) {
  currentRole = role;
  currentUser = ROLE_USERS[role];

  // Update UI
  document.getElementById('current-role').textContent = ROLE_CONFIG[role].name;
  document.getElementById('current-user-name').textContent = currentUser.name;

  // Filter sidebar by permissions
  document.querySelectorAll('.nav-item, .nav-section-title').forEach(el => {
    const roles = el.dataset.roles || '';
    const perms = el.dataset.perm || '';

    if (el.classList.contains('nav-section-title')) {
      // Show/hide section titles based on child items
      const sectionItems = document.querySelectorAll(`.nav-item[data-perm^="${perms}"]`);
      el.style.display = sectionItems.length > 0 ? 'block' : 'none';
      return;
    }

    if (roles.includes(role) || role === 'ADMIN') {
      el.style.display = 'flex';
    } else {
      el.style.display = 'none';
    }
  });

  // Navigate to dashboard
  navigateTo('dashboard');
}

// ---- Navigation ----
function navigateTo(page) {
  // Check permission
  const config = ROLE_CONFIG[currentRole];
  if (!config.pages.includes(page) && currentRole !== 'ADMIN') {
    alert('Bạn không có quyền truy cập trang này!');
    return;
  }

  currentPage = page;
  document.querySelectorAll('.nav-item').forEach(i => i.classList.toggle('active', i.dataset.page === page));
  document.querySelectorAll('.page').forEach(p => p.classList.toggle('active', p.id === `page-${page}`));

  const titles = {
    dashboard: 'Tổng quan', users: 'Người dùng & Vai trò', routes: 'Tuyến & Lịch Chạy',
    partners: 'Nhà xe & Tài xế',
    bookings: 'Giám sát đơn hàng', fulfillment: 'Nhiệm vụ phân công', intercity: 'Đặt vé',
    wallets: 'Ví & Thanh toán', refunds: 'Hoàn tiền', promos: 'Mã Ưu Đãi',
    commissions: 'Chiết Khấu', notifications: 'Thông báo',
    audit: 'Nhật ký hoạt động', monitoring: 'Giám sát hệ thống'
  };
  document.getElementById('page-title').textContent = titles[page] || page;
  renderPage(page);
}

function renderPage(page) {
  const renderers = {
    dashboard: renderDashboard, users: renderUsers, routes: renderRoutes,
    partners: renderPartners, drivers: renderDrivers, bookings: renderBookings,
    fulfillment: renderFulfillment, intercity: renderBookingTabs,
    wallets: renderWallets, refunds: renderRefunds,
    promos: renderPromos, commissions: renderCommissions, notifications: renderNotifications,
    audit: renderAudit, monitoring: renderMonitoring
  };
  if (renderers[page]) renderers[page]();
}

// ---- Helpers ----
function fmt(amount) { return new Intl.NumberFormat('vi-VN').format(amount) + 'đ'; }
function getCustomer(id) { return CUSTOMERS.find(c => c.id === id); }
function getCustomerName(id) { const c = getCustomer(id); return c ? c.name : '—'; }
function getDriverName(id) { if (!id) return '—'; const d = DRIVERS.find(d => d.id === id); return d ? d.name : '—'; }
function getPartnerName(id) { if (!id) return 'Cá nhân'; const p = PARTNERS.find(p => p.id === id); return p ? p.name : '—'; }
function getRouteName(id) { if (!id) return ''; const r = ROUTES.find(r => r.id === id); return r ? r.name : ''; }
function getUserName(id) { if (!id) return '—'; if (id === 'SYSTEM') return 'Hệ thống'; const u = PORTAL_USERS.find(u => u.id === id); return u ? u.name : id; }

function statusBadge(statusMap, key) {
  const s = statusMap[key];
  if (!s) return `<span class="badge badge-expired">${key || '—'}</span>`;
  const colorClass = {
    '#22C55E': 'badge-completed', '#4F8CFF': 'badge-accepted', '#FFB020': 'badge-pending',
    '#EF4444': 'badge-cancelled', '#7C5CFC': 'badge-picking', '#14B8A6': 'badge-progress',
    '#64748B': 'badge-expired', '#94A3B8': 'badge-offline'
  };
  return `<span class="badge ${colorClass[s.color] || 'badge-expired'}">${s.icon} ${s.label}</span>`;
}

function driverBadge(status) {
  const m = { online: 'badge-online Online', offline: 'badge-offline Offline', busy: 'badge-busy Đang chạy' };
  const [cls, label] = (m[status] || 'badge-offline ?').split(' ');
  return `<span class="badge ${cls}">${label}</span>`;
}

// ---- Modal ----
function openModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }
document.querySelectorAll('.modal-overlay').forEach(o => o.addEventListener('click', e => { if (e.target === o) o.classList.remove('show'); }));

// ---- Sidebar toggle ----
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('open'); }

// ---- Clock ----
function updateClock() {
  document.getElementById('header-time').textContent = new Date().toLocaleString('vi-VN', {
    weekday: 'short', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
}
setInterval(updateClock, 1000);
updateClock();

// ============================================
// DASHBOARD
// ============================================
function renderDashboard() {
  const s = DASHBOARD_STATS;
  document.getElementById('dashboard-stats').innerHTML = `
    <div class="stat-card accent"><div class="stat-card-header"><div class="stat-card-icon accent">📋</div><span class="stat-card-label">Bookings hôm nay</span></div><div class="stat-card-value">${s.todayBookings}</div><div class="stat-card-sub">+12% so với hôm qua</div></div>
    <div class="stat-card success"><div class="stat-card-header"><div class="stat-card-icon success">💰</div><span class="stat-card-label">Doanh thu</span></div><div class="stat-card-value">${fmt(s.todayRevenue)}</div><div class="stat-card-sub">+8.5% so với hôm qua</div></div>
    <div class="stat-card warning"><div class="stat-card-header"><div class="stat-card-icon warning">⏳</div><span class="stat-card-label">Chờ xử lý</span></div><div class="stat-card-value">${s.pendingBookings}</div><div class="stat-card-sub">Cần điều phối ngay</div></div>
    <div class="stat-card danger"><div class="stat-card-header"><div class="stat-card-icon danger">⚠️</div><span class="stat-card-label">SLA Violations</span></div><div class="stat-card-value">${s.slaViolations}</div><div class="stat-card-sub">Vượt SLA xử lý</div></div>
  `;

  // Chart
  const max = Math.max(...s.hourlyTrips, 1);
  document.getElementById('hourly-chart').innerHTML = s.hourlyTrips.map(v => `<div class="mini-chart-bar" style="height:${Math.max((v/max)*100,2)}%" data-value="${v}"></div>`).join('');
  document.getElementById('hourly-labels').innerHTML = s.hourlyTrips.map((_,i) => `<span>${String(i).padStart(2,'0')}</span>`).join('');

  // Recent bookings
  const recent = [...BOOKINGS].sort((a,b) => b.createdAt.localeCompare(a.createdAt)).slice(0,8);
  document.getElementById('recent-bookings').innerHTML = recent.map(b => {
    const vt = VEHICLE_TYPES[b.bookingType];
    return `<div class="recent-trip-item" onclick="showBookingDetail('${b.id}')">
      <span class="recent-trip-icon">${vt?.icon||'🚗'}</span>
      <div class="recent-trip-info"><div class="route">${b.pickup} → ${b.dropoff}</div><div class="meta">${b.bookingCode} · ${getCustomerName(b.customerId)} · ${b.createdAt.split(' ')[1]}</div></div>
      ${statusBadge(BOOKING_STATUSES, b.bookingStatus)}
      <span class="recent-trip-price">${fmt(b.fareSnapshot)}</span>
    </div>`;
  }).join('');

  // Service health mini
  document.getElementById('service-health-mini').innerHTML = SYSTEM_SERVICES.map(s => {
    const color = s.status === 'healthy' ? 'var(--success)' : s.status === 'warning' ? 'var(--warning)' : 'var(--danger)';
    return `<div style="display:flex;align-items:center;gap:8px;padding:6px 8px;margin-bottom:4px;background:var(--bg-input);border-radius:var(--radius-sm)">
      <span style="width:8px;height:8px;border-radius:50%;background:${color};flex-shrink:0"></span>
      <span style="flex:1;font-size:12px">${s.name}</span>
      <span style="font-size:11px;color:var(--text-muted)">${s.latency}</span>
    </div>`;
  }).join('');

  // Online drivers
  const online = DRIVERS.filter(d => d.status === 'online');
  document.getElementById('online-count').textContent = `${online.length} online`;
  document.getElementById('online-drivers-dash').innerHTML = online.map(d => `
    <div class="driver-item"><div class="driver-avatar">${d.avatar}</div>
    <div class="driver-info"><div class="name">${d.name}</div><div class="meta">${VEHICLE_TYPES[d.vehicleType]?.icon||''} ${d.plate} · ⭐ ${d.rating}</div></div>${driverBadge(d.status)}</div>
  `).join('');
}

// ============================================
// USERS & RBAC
// ============================================
function switchUserTab(tab, btn) {
  document.querySelectorAll('#page-users .tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('users-tab-users').style.display = tab === 'users' ? 'block' : 'none';
  document.getElementById('users-tab-roles').style.display = tab === 'roles' ? 'block' : 'none';
}

function switchPartnerTab(tab, btn) {
  document.querySelectorAll('#page-partners .tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('partners-tab-partners').style.display = tab === 'partners' ? 'block' : 'none';
  document.getElementById('partners-tab-drivers').style.display = tab === 'drivers' ? 'block' : 'none';
}

function switchRouteTab(tab, btn) {
  document.querySelectorAll('#page-routes .tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('routes-tab-schedules').style.display = tab === 'schedules' ? 'block' : 'none';
  document.getElementById('routes-tab-routes').style.display = tab === 'routes' ? 'block' : 'none';
  document.getElementById('routes-tab-seats').style.display = tab === 'seats' ? 'block' : 'none';
}

function createUser() {
  const name = document.getElementById('new-user-name').value.trim();
  const email = document.getElementById('new-user-email').value.trim();
  const phone = document.getElementById('new-user-phone').value.trim();
  const role = document.getElementById('new-user-role').value;

  if (!name || !email || !phone) {
    alert('Vui lòng điền đầy đủ thông tin');
    return;
  }

  const newUser = {
    id: 'USR' + String(PORTAL_USERS.length + 1).padStart(3, '0'),
    name, email, phone, roles: [role], status: 'active', lastLogin: '—', tenantId: 'T001'
  };

  PORTAL_USERS.unshift(newUser);
  closeModal('user-create-modal');
  document.getElementById('new-user-name').value = '';
  document.getElementById('new-user-email').value = '';
  document.getElementById('new-user-phone').value = '';
  renderUsers();
  alert('Tạo user thành công!');
}

function createRole() {
  const name = document.getElementById('new-role-name').value.trim();
  const code = document.getElementById('new-role-code').value.trim().toUpperCase();
  const checkboxes = document.querySelectorAll('#role-create-modal input[type="checkbox"]:checked');
  const permissions = Array.from(checkboxes).map(cb => cb.value);

  if (!name || !code) {
    alert('Vui lòng điền tên và mã vai trò');
    return;
  }

  const newRole = {
    id: 'ROLE' + String(ROLES.length + 1).padStart(3, '0'),
    name, code, permissions, usersCount: 0, status: 'active'
  };

  ROLES.unshift(newRole);
  closeModal('role-create-modal');
  document.getElementById('new-role-name').value = '';
  document.getElementById('new-role-code').value = '';
  checkboxes.forEach(cb => cb.checked = false);
  renderUsers();
  alert('Tạo vai trò thành công!');
}

function renderUsers() {
  document.getElementById('user-stats').innerHTML = `
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon accent">👥</div><span class="stat-card-label">Tổng Users</span></div><div class="stat-card-value">${PORTAL_USERS.length}</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon success">🔑</div><span class="stat-card-label">Roles</span></div><div class="stat-card-value">${ROLES.length}</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon warning">🟢</div><span class="stat-card-label">Active Users</span></div><div class="stat-card-value">${PORTAL_USERS.filter(u=>u.status==='active').length}</div></div>
  `;
  document.getElementById('roles-table-body').innerHTML = ROLES.map(r => `<tr>
    <td><span class="text-accent fw-600">${r.id}</span></td>
    <td class="fw-600">${r.name}</td>
    <td><code>${r.code}</code></td>
    <td><div style="display:flex;flex-wrap:wrap;gap:3px">${r.permissions.slice(0,4).map(p=>`<span class="route-tag" style="font-size:10px">${p}</span>`).join('')}${r.permissions.length>4?`<span class="text-muted" style="font-size:10px">+${r.permissions.length-4}</span>`:''}</div></td>
    <td class="fw-600">${r.usersCount}</td>
    <td><span class="badge badge-active">✅ Hoạt động</span></td>
    <td><button class="btn btn-sm btn-outline">✏️</button></td>
  </tr>`).join('');

  document.getElementById('users-table-body').innerHTML = PORTAL_USERS.map(u => `<tr>
    <td><span class="text-accent fw-600">${u.id}</span></td>
    <td class="fw-600">${u.name}</td>
    <td>${u.email}</td>
    <td>${u.phone}</td>
    <td>${u.roles.map(r=>`<span class="badge badge-accepted">${r}</span>`).join(' ')}</td>
    <td class="text-muted">${u.lastLogin}</td>
    <td><span class="badge ${u.status==='active'?'badge-active':'badge-cancelled'}">${u.status==='active'?'✅ Hoạt động':'⛔ Bị khóa'}</span></td>
    <td><button class="btn btn-sm btn-outline">✏️</button></td>
  </tr>`).join('');
}

// ============================================
// ROUTES & SCHEDULES
// ============================================
function populateScheduleOptions() {
  const routeSelect = document.getElementById('schedule-route');
  if (routeSelect && routeSelect.options.length <= 1) {
    ROUTES.forEach(r => {
      const opt = document.createElement('option');
      opt.value = r.id;
      opt.textContent = r.name;
      routeSelect.appendChild(opt);
    });
  }
  const opSelect = document.getElementById('schedule-operator');
  if (opSelect && opSelect.options.length <= 1) {
    PARTNERS.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = p.name;
      opSelect.appendChild(opt);
    });
  }
}

function createSchedule() {
  const routeId = document.getElementById('schedule-route').value;
  const operatorId = document.getElementById('schedule-operator').value;
  const departure = document.getElementById('schedule-departure').value;
  const arrival = document.getElementById('schedule-arrival').value;
  const seatLayoutId = document.getElementById('schedule-seat-layout').value;
  const daySelect = document.getElementById('schedule-days');
  const selectedDays = Array.from(daySelect.selectedOptions).map(o => o.value);
  const status = document.getElementById('schedule-status').value;

  if (!routeId || !operatorId || !departure || !arrival || selectedDays.length === 0) {
    alert('Vui lòng điền đầy đủ thông tin bắt buộc');
    return;
  }

  const newSchedule = {
    id: 'SCH' + String(SCHEDULES.length + 1).padStart(3, '0'),
    routeId,
    operatorId,
    departureTime: departure,
    arrivalTime: arrival,
    seatLayoutId,
    status,
    daysOfWeek: selectedDays
  };

  SCHEDULES.unshift(newSchedule);
  closeModal('schedule-create-modal');
  renderRoutes();
  alert('Tạo lịch chạy thành công!');
}

function renderRoutes() {
  populateScheduleOptions();
  document.getElementById('routes-table-body').innerHTML = ROUTES.map(r => `<tr>
    <td><span class="text-accent fw-600">${r.id}</span></td><td class="fw-600">${r.name}</td>
    <td>${r.distance} km</td><td>${r.duration}</td>
    <td><div style="display:flex;flex-wrap:wrap;gap:3px">${r.stops.map(s=>`<span class="route-tag" style="font-size:10px">${s}</span>`).join('')}</div></td>
    <td>${r.operators.map(op=>getPartnerName(op)).join(', ')}</td>
    <td><span class="badge badge-active">Active</span></td>
  </tr>`).join('');

  document.getElementById('schedules-table-body').innerHTML = SCHEDULES.map(s => {
    const layout = SEAT_LAYOUTS.find(l => l.id === s.seatLayoutId);
    return `<tr>
      <td><span class="text-accent fw-600">${s.id}</span></td>
      <td>${getRouteName(s.routeId)}</td>
      <td>${getPartnerName(s.operatorId)}</td>
      <td class="fw-600">${s.departureTime}</td>
      <td>${s.arrivalTime}</td>
      <td>${layout ? layout.name + ' (' + layout.totalSeats + ' chỗ)' : s.seatLayoutId}</td>
      <td><div style="display:flex;flex-wrap:wrap;gap:2px">${s.daysOfWeek.map(d=>`<span style="padding:1px 5px;background:var(--accent-glow);color:var(--accent);border-radius:4px;font-size:10px">${d}</span>`).join('')}</div></td>
      <td><button class="btn btn-sm btn-outline">✏️</button></td>
    </tr>`;
  }).join('');

  document.getElementById('seats-table-body').innerHTML = SEAT_LAYOUTS.map(s => `<tr>
    <td><span class="text-accent fw-600">${s.id}</span></td><td class="fw-600">${s.name}</td>
    <td><span class="badge badge-accepted">${s.type}</span></td><td class="fw-600">${s.totalSeats}</td>
  </tr>`).join('');
}

// ============================================
// PARTNERS
// ============================================
function renderPartners() {
  // Render partners table
  document.getElementById('partners-table-body').innerHTML = PARTNERS.map(p => `<tr>
    <td><span class="text-accent fw-600">${p.id}</span></td><td class="fw-600">${p.name}</td><td>${p.contact}</td><td>${p.phone}</td>
    <td class="fw-600">${p.vehicles}</td><td class="fw-600">${p.drivers}</td>
    <td><div class="partner-routes">${p.routes.map(r=>`<span class="route-tag">${r}</span>`).join('')}</div></td>
    <td class="fw-600">${p.commission}%</td>
    <td><span class="badge badge-${p.status}">${p.status==='active'?'✅ Hoạt động':'⛔ Ngừng'}</span></td>
    <td><div class="flex-center"><button class="btn-icon">👁️</button><button class="btn-icon">✏️</button></div></td>
  </tr>`).join('');

  // Render drivers table
  renderDrivers();
}

// ============================================
// DRIVERS
// ============================================
function renderDrivers() {
  let drivers = [...DRIVERS];
  const sf = document.getElementById('driver-status-filter')?.value;
  if (sf) drivers = drivers.filter(d => d.status === sf);
  const search = document.getElementById('driver-search')?.value?.toLowerCase();
  if (search) drivers = drivers.filter(d => d.name.toLowerCase().includes(search) || d.id.toLowerCase().includes(search) || d.plate.toLowerCase().includes(search));

  document.getElementById('driver-stats').innerHTML = `
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon accent">👥</div><span class="stat-card-label">Tổng tài xế</span></div><div class="stat-card-value">${DRIVERS.length}</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon success">🟢</div><span class="stat-card-label">Online</span></div><div class="stat-card-value">${DRIVERS.filter(d=>d.status==='online').length}</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon warning">🚗</div><span class="stat-card-label">Đang chạy</span></div><div class="stat-card-value">${DRIVERS.filter(d=>d.status==='busy').length}</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon danger">⚫</div><span class="stat-card-label">Offline</span></div><div class="stat-card-value">${DRIVERS.filter(d=>d.status==='offline').length}</div></div>
  `;
  document.getElementById('drivers-table-body').innerHTML = drivers.map(d => `<tr>
    <td><span class="text-accent fw-600">${d.id}</span></td>
    <td><div class="flex-center"><div class="driver-avatar" style="width:28px;height:28px;font-size:14px">${d.avatar}</div><span class="fw-600">${d.name}</span></div></td>
    <td>${d.phone}</td><td>${VEHICLE_TYPES[d.vehicleType]?.icon||''} ${VEHICLE_TYPES[d.vehicleType]?.label||d.vehicleType}</td>
    <td class="fw-600">${d.plate}</td><td>${getPartnerName(d.operatorId)}</td><td>⭐ ${d.rating}</td><td class="fw-600">${d.trips.toLocaleString()}</td>
    <td>${driverBadge(d.status)}</td>
    <td><button class="btn btn-sm btn-outline" onclick="editDriver('${d.id}')">✏️</button></td>
  </tr>`).join('') || `<tr><td colspan="10"><div class="empty-state"><div class="empty-state-icon">🔍</div><div class="empty-state-text">Không tìm thấy tài xế</div></div></td></tr>`;
}

function editDriver(driverId) {
  const driver = DRIVERS.find(d => d.id === driverId);
  if (!driver) return;
  alert('Chỉnh sửa tài xế: ' + driver.name);
}

function addDriver() {
  const name = document.getElementById('driver-name').value;
  const phone = document.getElementById('driver-phone').value;
  const vehicleType = document.getElementById('driver-vehicle-type').value;
  const plate = document.getElementById('driver-plate').value;
  const operatorId = document.getElementById('driver-operator').value;
  const status = document.getElementById('driver-status').value;

  if (!name || !phone || !plate) {
    alert('Vui lòng nhập đầy đủ thông tin!');
    return;
  }

  const newDriver = {
    id: 'DRV' + String(DRIVERS.length + 1).padStart(3, '0'),
    name: name,
    phone: phone,
    vehicleType: vehicleType,
    plate: plate,
    operatorId: operatorId || null,
    status: status,
    rating: 5.0,
    trips: 0,
    avatar: '👤',
    currentAssignmentId: null
  };

  DRIVERS.push(newDriver);
  closeModal('driver-modal');
  renderDrivers();

  // Clear form
  document.getElementById('driver-name').value = '';
  document.getElementById('driver-phone').value = '';
  document.getElementById('driver-plate').value = '';
}

// ============================================
// BOOKING MONITORING
// ============================================
function filterBookings(type) {
  if (type && type !== currentBookingType) {
    currentBookingType = type;
    document.querySelectorAll('#booking-tabs .tab-btn').forEach(b => b.classList.toggle('active', b.dataset.type === type));
  }
  renderBookings();
}

function renderBookings() {
  let bookings = [...BOOKINGS];
  if (currentBookingType !== 'ALL') bookings = bookings.filter(b => b.bookingType === currentBookingType);
  const sf = document.getElementById('booking-status-filter')?.value;
  if (sf) bookings = bookings.filter(b => b.bookingStatus === sf);
  const search = document.getElementById('booking-search')?.value?.toLowerCase();
  if (search) bookings = bookings.filter(b => b.bookingCode.toLowerCase().includes(search) || b.pickup.toLowerCase().includes(search) || b.dropoff.toLowerCase().includes(search) || getCustomerName(b.customerId).toLowerCase().includes(search));

  const canDispatch = hasPermission('fulfillment.assign') || currentRole === 'ADMIN';

  document.getElementById('bookings-table-body').innerHTML = bookings.map(b => {
    const vt = VEHICLE_TYPES[b.bookingType];
    return `<tr>
      <td><span class="text-accent fw-600">${b.bookingCode}</span></td>
      <td>${vt?vt.icon+' '+vt.label:b.bookingType}</td>
      <td>${getCustomerName(b.customerId)}</td>
      <td>${statusBadge(BOOKING_STATUSES, b.bookingStatus)}</td>
      <td>${statusBadge(PAYMENT_STATUSES, b.paymentStatus)}</td>
      <td>${b.fulfillmentStatus ? statusBadge(FULFILLMENT_STATUSES, b.fulfillmentStatus) : '<span class="text-muted">—</span>'}</td>
      <td style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${b.pickup}">${b.pickup}</td>
      <td class="fw-600">${fmt(b.fareSnapshot)}</td>
      <td class="text-muted">${b.createdAt}</td>
      <td><div class="flex-center">
        <button class="btn-icon" title="Chi tiết" onclick="showBookingDetail('${b.id}')">👁️</button>
        ${canDispatch && b.bookingStatus==='PENDING_CONFIRMATION'?`<button class="btn-icon" title="Điều phối" onclick="openDispatchModal('${b.id}')" style="border-color:var(--warning);color:var(--warning)">📡</button>`:''}
      </div></td>
    </tr>`;
  }).join('') || `<tr><td colspan="10"><div class="empty-state"><div class="empty-state-icon">🔍</div><div class="empty-state-text">Không tìm thấy booking</div></div></td></tr>`;
}

function showBookingDetail(id) {
  const b = BOOKINGS.find(x => x.id === id);
  if (!b) return;
  const vt = VEHICLE_TYPES[b.bookingType];
  const customer = getCustomer(b.customerId);
  const driver = b.driverId ? DRIVERS.find(d => d.id === b.driverId) : null;

  // Build state timeline
  const bookingStates = ['DRAFT', 'PENDING_CONFIRMATION', 'CONFIRMED', 'IN_PROGRESS', 'COMPLETED'];
  const currentIdx = bookingStates.indexOf(b.bookingStatus === 'CANCELLED' || b.bookingStatus === 'RESCHEDULE_REQUESTED' ? 'CONFIRMED' : b.bookingStatus);

  document.getElementById('booking-detail-content').innerHTML = `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px">
      <span style="font-size:32px">${vt?.icon||'🚗'}</span>
      <div><div class="fw-700" style="font-size:16px">${b.bookingCode}</div><div class="text-muted">${vt?.label||''} · ${b.id}</div></div>
    </div>

    <div style="display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap">
      ${statusBadge(BOOKING_STATUSES, b.bookingStatus)}
      ${statusBadge(PAYMENT_STATUSES, b.paymentStatus)}
      ${b.fulfillmentStatus ? statusBadge(FULFILLMENT_STATUSES, b.fulfillmentStatus) : ''}
    </div>

    <div class="form-grid" style="gap:12px">
      <div class="input-group"><label>Khách hàng</label><div style="padding:8px 0;font-size:13px">${customer ? customer.name+' · '+customer.phone : '—'}</div></div>
      <div class="input-group"><label>Tài xế</label><div style="padding:8px 0;font-size:13px">${driver ? driver.name+' · '+driver.phone : '<span class="text-warning">Chưa gán</span>'}</div></div>
      <div class="input-group full-width"><label>📍 Điểm đón</label><div style="padding:8px 0;font-size:13px">${b.pickup}</div></div>
      <div class="input-group full-width"><label>🏁 Điểm đến</label><div style="padding:8px 0;font-size:13px">${b.dropoff}</div></div>
      <div class="input-group"><label>Giá</label><div style="padding:8px 0;font-size:16px;font-weight:700;color:var(--success)">${fmt(b.fareSnapshot)}</div></div>
      <div class="input-group"><label>Khoảng cách</label><div style="padding:8px 0;font-size:13px">${b.distance} km</div></div>
      <div class="input-group"><label>Payment Ref</label><div style="padding:8px 0;font-size:13px;font-family:monospace">${b.paymentReference}</div></div>
      <div class="input-group"><label>Fulfillment Task</label><div style="padding:8px 0;font-size:13px;font-family:monospace">${b.fulfillmentTaskId||'—'}</div></div>
      ${b.seatNumbers ? `<div class="input-group"><label>Ghế</label><div style="padding:8px 0;font-size:13px">${b.seatNumbers.join(', ')}</div></div>` : ''}
      ${b.routeId ? `<div class="input-group"><label>Tuyến</label><div style="padding:8px 0;font-size:13px">${getRouteName(b.routeId)}</div></div>` : ''}
    </div>

    <div style="margin-top:20px"><label style="font-size:12px;font-weight:500;color:var(--text-secondary);display:block;margin-bottom:12px">Booking Lifecycle</label>
      <div style="display:flex;gap:4px">${bookingStates.map((key, i) => {
        const s = BOOKING_STATUSES[key];
        const active = i <= currentIdx;
        const current = key === b.bookingStatus;
        return `<div style="flex:1;text-align:center"><div style="height:4px;border-radius:4px;background:${active?s.color:'var(--border-color)'};margin-bottom:6px"></div><div style="font-size:10px;color:${current?s.color:'var(--text-muted)'};font-weight:${current?'600':'400'}">${s.icon} ${s.label}</div></div>`;
      }).join('')}</div>
      ${b.bookingStatus === 'CANCELLED' ? '<div style="margin-top:8px;text-align:center;color:var(--danger);font-size:12px;font-weight:600">❌ Booking đã bị hủy</div>' : ''}
      ${b.bookingStatus === 'RESCHEDULE_REQUESTED' ? '<div style="margin-top:8px;text-align:center;color:var(--purple);font-size:12px;font-weight:600">🔄 Yêu cầu đổi lịch đang chờ xử lý</div>' : ''}
    </div>
  `;

  const canDispatch = hasPermission('fulfillment.assign') || currentRole === 'ADMIN';
  const canCancel = hasPermission('booking.cancel') || currentRole === 'ADMIN';

  let actions = '<button class="btn btn-outline" onclick="closeModal(\'booking-detail-modal\')">Đóng</button>';
  if (canDispatch && b.bookingStatus === 'PENDING_CONFIRMATION') actions += `<button class="btn btn-primary" onclick="closeModal('booking-detail-modal');openDispatchModal('${b.id}')">📡 Điều phối</button>`;
  if (canCancel && ['PENDING_CONFIRMATION','CONFIRMED'].includes(b.bookingStatus)) actions += `<button class="btn btn-danger" onclick="cancelBooking('${b.id}')">Hủy booking</button>`;
  document.getElementById('booking-detail-actions').innerHTML = actions;
  openModal('booking-detail-modal');
}

function cancelBooking(id) {
  const b = BOOKINGS.find(x => x.id === id);
  if (b) { b.bookingStatus = 'CANCELLED'; b.paymentStatus = 'CANCELLED'; closeModal('booking-detail-modal'); renderPage(currentPage); updateBadges(); }
}

// ============================================
// FULFILLMENT TASKS
// ============================================
function renderFulfillment() {
  const pending = BOOKINGS.filter(b => b.bookingStatus === 'CONFIRMED' && (!b.fulfillmentStatus || b.fulfillmentStatus === 'PENDING'));
  const pendingFromConfirmed = BOOKINGS.filter(b => b.bookingStatus === 'PENDING_CONFIRMATION');
  const allPending = [...pending, ...pendingFromConfirmed];
  const available = DRIVERS.filter(d => d.status === 'online');
  const canAssign = hasPermission('fulfillment.assign') || currentRole === 'ADMIN';

  document.getElementById('fulfillment-stats').innerHTML = `
    <div class="stat-card warning"><div class="stat-card-header"><div class="stat-card-icon warning">⏳</div><span class="stat-card-label">Chờ gán</span></div><div class="stat-card-value">${allPending.length}</div></div>
    <div class="stat-card success"><div class="stat-card-header"><div class="stat-card-icon success">🟢</div><span class="stat-card-label">TX sẵn sàng</span></div><div class="stat-card-value">${available.length}</div></div>
    <div class="stat-card accent"><div class="stat-card-header"><div class="stat-card-icon accent">🛣️</div><span class="stat-card-label">Đang chạy</span></div><div class="stat-card-value">${FULFILLMENT_TASKS.filter(t=>t.status==='IN_PROGRESS').length}</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon info">✅</div><span class="stat-card-label">Hoàn thành</span></div><div class="stat-card-value">${FULFILLMENT_TASKS.filter(t=>t.status==='COMPLETED').length}</div></div>
  `;

  document.getElementById('dispatch-pending-count').textContent = `${allPending.length} chuyến`;
  const pendingListHtml = allPending.length ? allPending.map(b => {
    const vt = VEHICLE_TYPES[b.bookingType];
    return `<div class="dispatch-item" ${canAssign ? `onclick="openDispatchModal('${b.id}')"` : ''}>
      <div class="dispatch-item-header"><span class="dispatch-item-id">${b.bookingCode}</span><span class="dispatch-item-type">${vt?.icon||'🚗'}</span></div>
      <div class="dispatch-item-route"><span class="pickup">${b.pickup}</span><span class="dropoff">${b.dropoff}</span></div>
      <div class="dispatch-item-footer"><span class="dispatch-item-price">${fmt(b.fareSnapshot)}</span>${canAssign ? `<button class="btn btn-primary btn-sm" onclick="event.stopPropagation();openDispatchModal('${b.id}')">Gán tài xế</button>` : '<span class="text-muted" style="font-size:12px">Chỉ xem</span>'}</div>
    </div>`;
  }).join('') : '<div class="empty-state"><div class="empty-state-icon">🎉</div><div class="empty-state-text">Tất cả đã được gán</div></div>';
  document.getElementById('dispatch-pending-list').innerHTML = pendingListHtml;

  document.getElementById('dispatch-driver-count').textContent = `${available.length} tài xế`;
  document.getElementById('dispatch-driver-list').innerHTML = available.length ? available.map(d => `
    <div class="driver-item"><div class="driver-avatar">${d.avatar}</div>
    <div class="driver-info"><div class="name">${d.name}</div><div class="meta">${VEHICLE_TYPES[d.vehicleType]?.icon||''} ${d.plate} · ⭐ ${d.rating} · ${d.trips} chuyến</div></div>${driverBadge(d.status)}</div>
  `).join('') : '<div class="empty-state"><div class="empty-state-text">Không có tài xế</div></div>';

  document.getElementById('fulfillment-table-body').innerHTML = FULFILLMENT_TASKS.map(t => {
    const b = BOOKINGS.find(x => x.id === t.bookingId);
    return `<tr>
      <td><span class="text-accent fw-600">${t.id}</span></td>
      <td>${b ? b.bookingCode : t.bookingId}</td>
      <td class="fw-600">${getDriverName(t.driverId)}</td>
      <td>${statusBadge(FULFILLMENT_STATUSES, t.status)}</td>
      <td class="text-muted">${t.assignedAt}</td>
      <td class="text-muted">${t.startedAt||'—'}</td>
      <td class="text-muted">${t.completedAt||'—'}</td>
      <td>${canAssign && t.status==='ASSIGNED'?`<button class="btn btn-sm btn-outline" title="Gán lại" onclick="openDispatchModal('${t.bookingId}')">🔄 Gán lại</button>`:'—'}</td>
    </tr>`;
  }).join('');
}

function openDispatchModal(bookingId) {
  selectedDispatchBooking = BOOKINGS.find(b => b.id === bookingId);
  if (!selectedDispatchBooking) return;
  const vt = VEHICLE_TYPES[selectedDispatchBooking.bookingType];
  document.getElementById('dispatch-trip-info').innerHTML = `
    <div class="flex-center" style="margin-bottom:8px"><span style="font-size:20px">${vt?.icon||'🚗'}</span><span class="fw-600">${selectedDispatchBooking.bookingCode}</span><span class="text-muted">·</span><span>${vt?.label||''}</span><span class="recent-trip-price" style="margin-left:auto">${fmt(selectedDispatchBooking.fareSnapshot)}</span></div>
    <div style="font-size:12px;color:var(--text-secondary)">📍 ${selectedDispatchBooking.pickup}<br>🏁 ${selectedDispatchBooking.dropoff}</div>`;
  const avail = DRIVERS.filter(d => d.status === 'online');
  document.getElementById('dispatch-driver-select').innerHTML = `<option value="">-- Chọn tài xế --</option>` + avail.map(d => `<option value="${d.id}">${d.avatar} ${d.name} · ${VEHICLE_TYPES[d.vehicleType]?.icon||''} ${d.plate} · ⭐${d.rating}</option>`).join('');
  openModal('dispatch-modal');
}

function assignDriver() {
  const driverId = document.getElementById('dispatch-driver-select').value;
  if (!driverId || !selectedDispatchBooking) return;
  selectedDispatchBooking.driverId = driverId;
  selectedDispatchBooking.bookingStatus = 'CONFIRMED';
  selectedDispatchBooking.paymentStatus = 'CONFIRMED';
  selectedDispatchBooking.fulfillmentStatus = 'ASSIGNED';
  const driver = DRIVERS.find(d => d.id === driverId);
  if (driver) driver.status = 'busy';
  closeModal('dispatch-modal');
  selectedDispatchBooking = null;
  renderPage(currentPage);
  updateBadges();
}

// ============================================
// WALLETS
// ============================================
function renderWallets() {
  let wallets = [...WALLETS];
  const tf = document.getElementById('wallet-type-filter')?.value;
  if (tf) wallets = wallets.filter(w => w.ownerType === tf);
  const search = document.getElementById('wallet-search')?.value?.toLowerCase();
  if (search) wallets = wallets.filter(w => w.ownerName.toLowerCase().includes(search));

  const total = WALLETS.reduce((s,w) => s + w.balance, 0);
  const pending = WALLETS.reduce((s,w) => s + w.pendingBalance, 0);
  document.getElementById('wallet-stats').innerHTML = `
    <div class="stat-card accent"><div class="stat-card-header"><div class="stat-card-icon accent">💰</div><span class="stat-card-label">Tổng số dư</span></div><div class="stat-card-value">${fmt(total)}</div></div>
    <div class="stat-card warning"><div class="stat-card-header"><div class="stat-card-icon warning">🔒</div><span class="stat-card-label">Tạm giữ</span></div><div class="stat-card-value">${fmt(pending)}</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon success">📊</div><span class="stat-card-label">Tổng ví</span></div><div class="stat-card-value">${WALLETS.length}</div></div>
  `;

  const ownerTypeLabels = { CUSTOMER: '👤 Khách hàng', DRIVER: '🧑‍✈️ Tài xế', PARTNER: '🤝 Đối tác', SYSTEM: '🖥️ Hệ thống' };
  document.getElementById('wallets-table-body').innerHTML = wallets.map(w => `<tr>
    <td><span class="text-accent fw-600">${w.id}</span></td><td class="fw-600">${w.ownerName}</td>
    <td><span class="badge badge-accepted">${ownerTypeLabels[w.ownerType]||w.ownerType}</span></td>
    <td><span class="badge ${w.walletType==='MAIN'?'badge-accepted':w.walletType==='BONUS'?'badge-pending':'badge-picking'}">${WALLET_TYPES[w.walletType]?.icon||''} ${WALLET_TYPES[w.walletType]?.label||w.walletType}</span></td>
    <td class="fw-700 ${w.balance>0?'text-success':'text-muted'}">${fmt(w.balance)}</td>
    <td class="${w.pendingBalance>0?'text-warning':'text-muted'}">${fmt(w.pendingBalance)}</td>
    <td><span class="badge ${WALLET_STATUS[w.status]?.class||'badge-expired'}">${WALLET_STATUS[w.status]?.label||w.status}</span></td>
    <td><div class="flex-center"><button class="btn btn-sm btn-outline">💳 Nạp</button><button class="btn-icon">📋</button></div></td>
  </tr>`).join('');

  document.getElementById('transactions-table-body').innerHTML = WALLET_TRANSACTIONS.map(tx => {
    const t = TRANSACTION_TYPES[tx.type] || { label: tx.type, class: '' };
    const w = WALLETS.find(w => w.id === tx.walletId);
    return `<tr>
      <td class="text-muted">${tx.id}</td><td class="fw-600">${w?w.ownerName:tx.walletId}</td>
      <td><span class="badge ${tx.direction==='CREDIT'?'badge-completed':'badge-cancelled'}">${tx.direction==='CREDIT'?'↑ CREDIT':'↓ DEBIT'}</span></td>
      <td>${t.label}</td>
      <td class="fw-700 ${tx.direction==='CREDIT'?'text-success':'text-danger'}">${tx.direction==='CREDIT'?'+':'−'}${fmt(tx.amount)}</td>
      <td>${fmt(tx.balance)}</td>
      <td class="text-muted" style="font-family:monospace;font-size:11px">${tx.referenceType}:${tx.referenceId}</td>
      <td><span class="badge badge-${tx.status==='SUCCESS'?'completed':tx.status==='PENDING'?'pending':'cancelled'}">${tx.status}</span></td>
      <td class="text-muted">${tx.createdAt}</td>
    </tr>`;
  }).join('');
}

// ============================================
// REFUNDS
// ============================================
function renderRefunds() {
  const pending = REFUNDS.filter(r => r.status === 'PENDING').length;
  const processing = REFUNDS.filter(r => r.status === 'PROCESSING').length;
  const success = REFUNDS.filter(r => r.status === 'SUCCESS').length;
  const totalAmt = REFUNDS.filter(r=>r.status==='SUCCESS').reduce((s,r)=>s+r.amount,0);

  document.getElementById('refund-stats').innerHTML = `
    <div class="stat-card warning"><div class="stat-card-header"><div class="stat-card-icon warning">⏳</div><span class="stat-card-label">Chờ xử lý</span></div><div class="stat-card-value">${pending}</div></div>
    <div class="stat-card accent"><div class="stat-card-header"><div class="stat-card-icon accent">⚙️</div><span class="stat-card-label">Đang xử lý</span></div><div class="stat-card-value">${processing}</div></div>
    <div class="stat-card success"><div class="stat-card-header"><div class="stat-card-icon success">✅</div><span class="stat-card-label">Thành công</span></div><div class="stat-card-value">${success}</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon info">💸</div><span class="stat-card-label">Tổng hoàn tiền</span></div><div class="stat-card-value">${fmt(totalAmt)}</div></div>
  `;

  document.getElementById('refunds-table-body').innerHTML = REFUNDS.map(r => `<tr>
    <td><span class="text-accent fw-600">${r.id}</span></td>
    <td><span class="fw-600">${r.bookingCode}</span></td>
    <td>${getCustomerName(r.customerId)}</td>
    <td class="fw-700 text-warning">${fmt(r.amount)}</td>
    <td>${r.reason}</td>
    <td><span class="badge badge-accepted">${r.refundMethod==='wallet'?'💰 Ví chính':'🎁 Ví bonus'}</span></td>
    <td>${getUserName(r.processedBy)}</td>
    <td>${statusBadge(REFUND_STATUSES, r.status)}</td>
    <td class="text-muted">${r.createdAt}</td>
    <td>${r.status==='PENDING'?'<button class="btn btn-sm btn-primary">Xử lý</button>':''}</td>
  </tr>`).join('');
}

// ============================================
// PROMOS
// ============================================
function renderPromos() {
  const active = PROMOS.filter(p => p.status === 'active');
  const totalUsed = PROMOS.reduce((s,p) => s + p.used, 0);
  document.getElementById('promo-stats').innerHTML = `
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon accent">🎫</div><span class="stat-card-label">Tổng mã</span></div><div class="stat-card-value">${PROMOS.length}</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon success">✅</div><span class="stat-card-label">Đang hoạt động</span></div><div class="stat-card-value">${active.length}</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon warning">📊</div><span class="stat-card-label">Lượt sử dụng</span></div><div class="stat-card-value">${totalUsed.toLocaleString()}</div></div>
  `;
  const statusMap = { active: 'badge-active', expired: 'badge-expired', scheduled: 'badge-scheduled' };
  const statusLabel = { active: '✅ Hoạt động', expired: '⛔ Hết hạn', scheduled: '📅 Lên lịch' };
  document.getElementById('promos-table-body').innerHTML = PROMOS.map(p => {
    const pct = Math.round((p.used/p.usageLimit)*100);
    return `<tr>
      <td><span class="text-accent fw-700" style="font-family:monospace">${p.code}</span></td>
      <td>${p.type==='percent'?'📊 %':'💵 Cố định'}</td>
      <td class="fw-600">${p.type==='percent'?p.value+'%':fmt(p.value)}</td>
      <td>${fmt(p.maxDiscount)}</td>
      <td>${fmt(p.minOrder)}</td>
      <td>${p.vehicleTypes.map(v=>VEHICLE_TYPES[v]?.icon||'').join(' ')}</td>
      <td><div style="display:flex;align-items:center;gap:8px"><div style="flex:1;height:4px;background:var(--border-color);border-radius:4px;min-width:60px"><div style="height:100%;width:${pct}%;background:${pct>=90?'var(--danger)':'var(--accent)'};border-radius:4px"></div></div><span class="text-muted" style="font-size:11px">${p.used}/${p.usageLimit}</span></div></td>
      <td class="text-muted" style="font-size:12px">${p.startDate}<br>${p.endDate}</td>
      <td><span class="badge ${statusMap[p.status]||''}">${statusLabel[p.status]||p.status}</span></td>
      <td><div class="flex-center"><button class="btn-icon">✏️</button>${p.status==='active'?'<button class="btn-icon" style="color:var(--danger)">⛔</button>':''}</div></td>
    </tr>`;
  }).join('');
}

// ============================================
// COMMISSIONS
// ============================================
function renderCommissions() {
  document.getElementById('commission-config').innerHTML = COMMISSIONS.map(c => {
    const vt = VEHICLE_TYPES[c.vehicleType];
    return `<div class="commission-card"><div class="commission-card-header"><span class="commission-card-icon">${vt?.icon||'🚗'}</span><div><div class="commission-card-title">${vt?.label||c.vehicleType}</div><div class="commission-card-subtitle">${c.description}</div></div></div>
    <div class="commission-rate"><span class="commission-rate-value">${c.rate}</span><span class="commission-rate-unit">%</span></div>
    <button class="btn btn-outline btn-sm" style="width:100%">✏️ Chỉnh sửa</button></div>`;
  }).join('');

  document.getElementById('commission-history-body').innerHTML = COMMISSION_HISTORY.map(ch => {
    const vt = VEHICLE_TYPES[ch.vehicleType];
    const b = BOOKINGS.find(x => x.id === ch.bookingId);
    return `<tr><td class="text-muted">${ch.id}</td><td><span class="text-accent fw-600">${b?b.bookingCode:ch.bookingId}</span></td><td class="fw-600">${getDriverName(ch.driverId)}</td><td>${vt?.icon||''} ${vt?.label||ch.vehicleType}</td><td>${fmt(ch.tripPrice)}</td><td class="fw-600">${ch.rate}%</td><td class="fw-700 text-warning">${fmt(ch.amount)}</td><td class="text-muted">${ch.createdAt}</td></tr>`;
  }).join('');
}

// ============================================
// NOTIFICATIONS
// ============================================
function renderNotifications() {
  const delivered = NOTIFICATIONS.filter(n => n.status === 'delivered').length;
  const failed = NOTIFICATIONS.filter(n => n.status === 'failed').length;
  const pending = NOTIFICATIONS.filter(n => n.status === 'pending').length;
  document.getElementById('notification-stats').innerHTML = `
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon accent">🔔</div><span class="stat-card-label">Tổng</span></div><div class="stat-card-value">${NOTIFICATIONS.length}</div></div>
    <div class="stat-card success"><div class="stat-card-header"><div class="stat-card-icon success">✅</div><span class="stat-card-label">Delivered</span></div><div class="stat-card-value">${delivered}</div></div>
    <div class="stat-card danger"><div class="stat-card-header"><div class="stat-card-icon danger">❌</div><span class="stat-card-label">Failed</span></div><div class="stat-card-value">${failed}</div></div>
    <div class="stat-card warning"><div class="stat-card-header"><div class="stat-card-icon warning">⏳</div><span class="stat-card-label">Pending</span></div><div class="stat-card-value">${pending}</div></div>
  `;
  const typeLabels = { booking_created: '📋 Booking tạo', payment_confirmed: '💳 Payment OK', driver_assigned: '👤 Gán TX', trip_completed: '🏁 Hoàn thành', booking_cancelled: '❌ Hủy', refund_completed: '↩️ Hoàn tiền' };
  const statusBadges = { delivered: 'badge-completed', failed: 'badge-cancelled', pending: 'badge-pending' };

  document.getElementById('notifications-table-body').innerHTML = NOTIFICATIONS.map(n => `<tr>
    <td class="text-muted">${n.id}</td>
    <td>${typeLabels[n.type]||n.type}</td>
    <td><span class="badge badge-accepted">${n.channel.toUpperCase()}</span></td>
    <td class="fw-600">${n.recipient}</td>
    <td style="max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${n.content}</td>
    <td><span class="badge ${statusBadges[n.status]||'badge-expired'}">${n.status}${n.retryCount?' (retry:'+n.retryCount+')':''}</span></td>
    <td class="text-muted">${n.createdAt}</td>
  </tr>`).join('');
}

// ============================================
// AUDIT LOGS
// ============================================
function renderAudit() {
  let logs = [...AUDIT_LOGS];
  const af = document.getElementById('audit-action-filter')?.value;
  if (af) logs = logs.filter(l => l.action.startsWith(af));
  const search = document.getElementById('audit-search')?.value?.toLowerCase();
  if (search) logs = logs.filter(l => l.traceId.toLowerCase().includes(search) || l.target.toLowerCase().includes(search) || l.action.toLowerCase().includes(search));

  const actionColors = { 'booking': 'badge-accepted', 'payment': 'badge-completed', 'fulfillment': 'badge-picking', 'refund': 'badge-pending', 'wallet': 'badge-progress', 'user': 'badge-cancelled' };

  document.getElementById('audit-table-body').innerHTML = logs.map(l => {
    const actionType = l.action.split('.')[0];
    return `<tr>
      <td class="text-muted" style="font-size:12px">${l.timestamp}</td>
      <td><span class="badge ${actionColors[actionType]||'badge-expired'}">${l.action}</span></td>
      <td class="fw-600">${getUserName(l.actor)}</td>
      <td><span class="badge badge-expired">${l.actorRole}</span></td>
      <td><span class="text-accent fw-600">${l.target}</span></td>
      <td>${l.sourceSite}</td>
      <td style="font-family:monospace;font-size:11px;color:var(--text-muted)">${l.traceId}</td>
      <td style="font-size:11px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
        ${l.before ? `<span class="text-danger">${l.before}</span> → ` : ''}
        <span class="text-success">${l.after||''}</span>
      </td>
    </tr>`;
  }).join('');
}

// ============================================
// SYSTEM MONITORING
// ============================================
function renderMonitoring() {
  const healthy = SYSTEM_SERVICES.filter(s => s.status === 'healthy').length;
  const warning = SYSTEM_SERVICES.filter(s => s.status === 'warning').length;
  document.getElementById('monitoring-stats').innerHTML = `
    <div class="stat-card success"><div class="stat-card-header"><div class="stat-card-icon success">💚</div><span class="stat-card-label">Healthy</span></div><div class="stat-card-value">${healthy}</div></div>
    <div class="stat-card warning"><div class="stat-card-header"><div class="stat-card-icon warning">⚠️</div><span class="stat-card-label">Warning</span></div><div class="stat-card-value">${warning}</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon accent">🖥️</div><span class="stat-card-label">Tổng Services</span></div><div class="stat-card-value">${SYSTEM_SERVICES.length}</div></div>
  `;

  document.getElementById('services-table-body').innerHTML = SYSTEM_SERVICES.map(s => {
    const color = s.status === 'healthy' ? 'var(--success)' : 'var(--warning)';
    return `<tr>
      <td class="fw-600"><div class="flex-center"><span style="width:10px;height:10px;border-radius:50%;background:${color}"></span>${s.name}</div></td>
      <td><span class="badge ${s.status==='healthy'?'badge-completed':'badge-pending'}">${s.status.toUpperCase()}</span></td>
      <td class="fw-600 text-success">${s.uptime}</td>
      <td>${s.latency}</td>
      <td class="${parseFloat(s.errorRate)>0?'text-warning':'text-success'}">${s.errorRate}</td>
    </tr>`;
  }).join('');
}

// ============================================
// BADGES
// ============================================
function updateBadges() {
  const pending = BOOKINGS.filter(b => b.bookingStatus === 'PENDING_CONFIRMATION').length;
  const el1 = document.getElementById('pending-badge');
  const el2 = document.getElementById('fulfillment-badge');
  const el3 = document.getElementById('refund-badge');
  if (el1) { el1.textContent = pending; el1.style.display = pending > 0 ? '' : 'none'; }
  if (el2) { el2.textContent = pending; el2.style.display = pending > 0 ? '' : 'none'; }
  const refPending = REFUNDS.filter(r => r.status === 'PENDING').length;
  if (el3) { el3.textContent = refPending; el3.style.display = refPending > 0 ? '' : 'none'; }
}

// ============================================
// INIT
// ============================================
function init() {
  // Initialize role
  switchRole('ADMIN');

  // Update badges
  updateBadges();

  // Handle responsive
  const mq = window.matchMedia('(max-width: 768px)');
  function handleResize(e) { document.getElementById('menu-toggle').style.display = e.matches ? 'flex' : 'none'; }
  mq.addEventListener('change', handleResize);
  handleResize(mq);
}
document.addEventListener('DOMContentLoaded', init);

// ============================================
// KPI & SLA RENDERING
// ============================================
function renderKPI() {
  const kpiHTML = Object.entries(KPI_TARGETS).map(([key, kpi]) => {
    let progress = (kpi.current / kpi.target) * 100;
    let status = 'success';
    if (key === 'digitizationRate' || key === 'paymentSuccessRate' || key === 'portalAvailability' || key === 'auditCoverage') {
      if (progress < 100) status = 'warning';
      if (progress < 95) status = 'danger';
    } else {
      // For time-based KPIs, lower is better
      if (progress > 100) status = 'danger';
      if (progress > 90 && progress <= 100) status = 'warning';
    }
    const displayValue = kpi.isTime ? formatTime(kpi.current) : kpi.current + kpi.unit;
    return `
      <div class="kpi-card ${status}">
        <div class="kpi-label">${kpi.label}</div>
        <div class="kpi-value">${displayValue}</div>
        <div class="kpi-target">Target: ${kpi.isTime ? formatTime(kpi.target) : kpi.target + kpi.unit}</div>
        <div class="kpi-progress">
          <div class="kpi-progress-bar ${status}" style="width: ${Math.min(progress, 100)}%"></div>
        </div>
      </div>
    `;
  }).join('');
  return kpiHTML;
}

function formatTime(seconds) {
  if (seconds < 60) return seconds + 's';
  if (seconds < 3600) return Math.floor(seconds / 60) + 'm ' + (seconds % 60) + 's';
  return Math.floor(seconds / 3600) + 'h ' + Math.floor((seconds % 3600) / 60) + 'm';
}

function renderSLA() {
  return SLA_METRICS.map(sla => {
    const status = SLA_STATUS[sla.status];
    return `
      <tr>
        <td><span class="text-accent fw-600">${sla.id}</span></td>
        <td class="fw-600">${sla.name}</td>
        <td><span class="badge badge-pending" style="background: ${status.color}20; color: ${status.color}">${status.icon} ${status.label}</span></td>
        <td>${sla.target}</td>
        <td>${sla.current}</td>
        <td>${sla.avg}</td>
        <td>${sla.passed}/${sla.total}</td>
        <td class="${sla.failed > 0 ? 'text-danger' : 'text-success'}">${sla.failed}</td>
      </tr>
    `;
  }).join('');
}

function renderBookingStateMachine(currentStatus) {
  const statusOrder = ['DRAFT', 'SEARCHED', 'PENDING_CONFIRMATION', 'CONFIRMED', 'IN_PROGRESS', 'COMPLETED'];
  const currentIdx = statusOrder.indexOf(currentStatus);

  return BOOKING_STATE_MACHINE.map((state, idx) => {
    let stepClass = '';
    if (currentStatus === 'CANCELLED' || currentStatus === 'RESCHEDULE_REQUESTED') {
      if (idx < currentIdx) stepClass = 'completed';
    } else {
      if (idx < currentIdx) stepClass = 'completed';
      if (idx === currentIdx) stepClass = 'active';
    }

    return `
      <div class="state-step ${stepClass}">
        <div class="state-icon">${state.icon}</div>
        <div class="state-label">${state.label}</div>
      </div>
      ${idx < BOOKING_STATE_MACHINE.length - 1 ? `<div class="state-connector ${stepClass}"></div>` : ''}
    `;
  }).join('');
}

// ============================================
// AGENT SITE PAGES
// ============================================
function renderAgentDashboard() {
  document.getElementById('dashboard-stats').innerHTML = `
    <div class="stat-card accent"><div class="stat-card-header"><div class="stat-card-icon accent">📋</div><span class="stat-card-label">Bookings hôm nay</span></div><div class="stat-card-value">${AGENTS[0].todayBookings}</div><div class="stat-card-sub">+20% so với hôm qua</div></div>
    <div class="stat-card success"><div class="stat-card-header"><div class="stat-card-icon success">💰</div><span class="stat-card-label">Doanh thu hôm nay</span></div><div class="stat-card-value">${fmt(AGENTS[0].todayRevenue)}</div><div class="stat-card-sub">+15% so với hôm qua</div></div>
    <div class="stat-card warning"><div class="stat-card-header"><div class="stat-card-icon warning">👥</div><span class="stat-card-label">Khách hàng mới</span></div><div class="stat-card-value">3</div><div class="stat-card-sub">Tuần này</div></div>
    <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon info">💳</div><span class="stat-card-label">Số dư ví</span></div><div class="stat-card-value">${fmt(AGENTS[0].walletBalance)}</div><div class="stat-card-sub">Sẵn sàng rút</div></div>
  `;

  // Recent Agent Bookings
  const recent = [...BOOKINGS].sort((a,b) => b.createdAt.localeCompare(a.createdAt)).slice(0,6);
  document.getElementById('recent-bookings').innerHTML = recent.map(b => {
    const vt = VEHICLE_TYPES[b.bookingType];
    return `<div class="recent-trip-item" onclick="showBookingDetail('${b.id}')">
      <span class="recent-trip-icon">${vt?.icon||'🚗'}</span>
      <div class="recent-trip-info"><div class="route">${b.pickup} → ${b.dropoff}</div><div class="meta">${b.bookingCode} · ${getCustomerName(b.customerId)}</div></div>
      ${statusBadge(BOOKING_STATUSES, b.bookingStatus)}
    </div>`;
  }).join('');

  // Mini chart
  const max = Math.max(...DASHBOARD_STATS.hourlyTrips, 1);
  document.getElementById('hourly-chart').innerHTML = DASHBOARD_STATS.hourlyTrips.map(v => `<div class="mini-chart-bar" style="height:${Math.max((v/max)*100,2)}%" data-value="${v}"></div>`).join('');
  document.getElementById('hourly-labels').innerHTML = DASHBOARD_STATS.hourlyTrips.map((_,i) => `<span>${String(i).padStart(2,'0')}</span>`).join('');
}

function renderBookingTabs() {
  // Set default tab to intercity if not set
  const activeTab = document.querySelector('#page-bookings .tab-btn.active');
  if (!activeTab) {
    document.querySelector('#page-bookings .tab-btn[data-tab="intercity"]')?.classList.add('active');
    document.getElementById('booking-tab-intercity').style.display = 'block';
    document.getElementById('booking-tab-registration').style.display = 'none';
  }
  populateTripCreateOptions();
  renderIntercityBooking();
  renderRegistrations();
}

function populateTripCreateOptions() {
  // Populate route dropdown
  const routeSelect = document.getElementById('trip-route');
  if (routeSelect && routeSelect.options.length <= 1) {
    INTERCITY_ROUTES.forEach(r => {
      const opt = document.createElement('option');
      opt.value = r.id;
      opt.textContent = `${r.origin} → ${r.destination}`;
      routeSelect.appendChild(opt);
    });
  }

  // Populate operator dropdown
  const opSelect = document.getElementById('trip-operator');
  if (opSelect && opSelect.options.length <= 1) {
    PARTNERS.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = p.name;
      opSelect.appendChild(opt);
    });
  }
}

function createIntercityTrip() {
  const routeId = document.getElementById('trip-route').value;
  const operatorId = document.getElementById('trip-operator').value;
  const date = document.getElementById('trip-date').value;
  const departureTime = document.getElementById('trip-departure-time').value;
  const arrivalTime = document.getElementById('trip-arrival-time').value;
  const vehicleType = document.getElementById('trip-vehicle-type').value;
  const price = parseInt(document.getElementById('trip-price').value);
  const seatsTotal = parseInt(document.getElementById('trip-seats').value);

  if (!routeId || !operatorId || !date || !departureTime || !arrivalTime || !price || !seatsTotal) {
    alert('Vui lòng điền đầy đủ thông tin bắt buộc');
    return;
  }

  const operator = PARTNERS.find(p => p.id === operatorId);

  // Calculate duration
  const depH = parseInt(departureTime.split(':')[0]);
  const arrH = parseInt(arrivalTime.split(':')[0]);
  const durationHours = arrH >= depH ? arrH - depH : (24 - depH) + arrH;

  const newTrip = {
    id: 'TRP' + String(INTERCITY_TRIPS.length + 1).padStart(3, '0'),
    routeId,
    operatorId,
    operatorName: operator?.name || 'Nhà xe mới',
    departureTime,
    arrivalTime,
    duration: durationHours + 'h',
    vehicleType,
    price,
    seatsTotal,
    seatsAvailable: seatsTotal,
    status: 'available',
    date
  };

  INTERCITY_TRIPS.unshift(newTrip);
  closeModal('trip-create-modal');
  renderIntercityBooking();
  alert('Tạo chuyến xe thành công!');
}

function renderIntercityBooking() {
  // Show all available intercity trips by default
  const origin = document.getElementById('intercity-origin')?.value || 'TP.HCM';
  const trips = INTERCITY_TRIPS.filter(t => {
    const route = INTERCITY_ROUTES.find(r => r.id === t.routeId);
    return route && route.origin === origin && t.status === 'available';
  });

  if (trips.length > 0) {
    document.getElementById('intercity-results').innerHTML = `
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:16px">
    ` + trips.map(t => {
      const route = INTERCITY_ROUTES.find(r => r.id === t.routeId);
      const sold = t.seatsTotal - t.seatsAvailable;
      const percent = Math.round((sold / t.seatsTotal) * 100);
      const textColor = percent >= 90 ? 'var(--danger)' : percent >= 70 ? 'var(--warning)' : 'var(--success)';

      return `
      <div class="trip-card" onclick="showTripDetail('${t.id}')" style="cursor:pointer;padding:16px">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
          <div>
            <div style="font-weight:600;font-size:14px;color:var(--text-primary)">${route?.origin || '—'} → ${route?.destination || '—'}</div>
            <div style="font-size:12px;color:var(--text-muted)">${t.operatorName}</div>
          </div>
          <div style="text-align:right">
            <div style="font-weight:700;font-size:16px;color:var(--success)">${fmt(t.price)}</div>
            <div style="font-size:11px;color:var(--text-muted)">/khách</div>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
          <div>
            <div style="font-size:11px;color:var(--text-muted)">🕐 Giờ chạy</div>
            <div style="font-weight:600">${t.departureTime} - ${t.arrivalTime}</div>
          </div>
          <div>
            <div style="font-size:11px;color:var(--text-muted)">📅 Ngày chạy</div>
            <div style="font-weight:600">${t.date}</div>
          </div>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <div>
            <span style="font-size:12px;padding:2px 8px;background:var(--accent-glow);color:var(--accent);border-radius:4px">${t.vehicleType}</span>
          </div>
          <div style="font-size:12px;color:var(--text-muted)">${t.seatsAvailable} chỗ trống</div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="flex:1;height:6px;background:var(--border-color);border-radius:3px">
            <div style="height:100%;width:${percent}%;background:${textColor};border-radius:3px"></div>
          </div>
          <span style="font-size:11px;color:${textColor};font-weight:500">${sold}/${t.seatsTotal}</span>
        </div>
      </div>
    `}).join('') + `</div>`;
  } else {
    document.getElementById('intercity-results').innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🚌</div>
        <div class="empty-state-text">Chưa có chuyến nào từ ${origin}</div>
      </div>
    `;
  }
}

// ---- Tab Switching ----
function switchBookingTab(tab, btn) {
  document.querySelectorAll('#page-bookings .tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('booking-tab-intercity').style.display = tab === 'intercity' ? 'block' : 'none';
  document.getElementById('booking-tab-registration').style.display = tab === 'registration' ? 'block' : 'none';
  if (tab === 'intercity') renderIntercityBooking();
  if (tab === 'registration') renderRegistrations();
}

// ---- REGISTRATIONS ----
function renderRegistrations() {
  const search = document.getElementById('registration-search')?.value?.toLowerCase() || '';
  let regs = REGISTRATIONS.filter(r =>
    r.plate.toLowerCase().includes(search) ||
    r.ownerName.toLowerCase().includes(search) ||
    r.ownerPhone.includes(search)
  );

  const statusMap = {
    pending: { label: 'Chờ xác nhận', class: 'badge-pending' },
    confirmed: { label: 'Đã xác nhận', class: 'badge-active' },
    completed: { label: 'Hoàn thành', class: 'badge-success' },
    cancelled: { label: 'Đã hủy', class: 'badge-cancelled' }
  };
  const serviceLabels = { normal: 'Thường', express: 'Nhanh', home: 'Tại nhà' };

  document.getElementById('registrations-table-body').innerHTML = regs.map(r => `
    <tr>
      <td><span class="text-accent fw-600">${r.id}</span></td>
      <td><span class="fw-600">${r.plate}</span></td>
      <td>${r.ownerName}</td>
      <td>${r.ownerPhone}</td>
      <td>${r.centerName}</td>
      <td>${r.bookingDate} ${r.bookingTime}</td>
      <td>${serviceLabels[r.service]}</td>
      <td class="fw-600 text-success">${fmt(r.price)}</td>
      <td><span class="badge ${statusMap[r.status]?.class || ''}">${statusMap[r.status]?.label || r.status}</span></td>
      <td>
        <button class="btn btn-sm btn-outline" title="Xem chi tiết" onclick="viewRegistration('${r.id}')">👁️</button>
        ${r.status === 'pending' ? `<button class="btn btn-sm btn-primary" title="Xác nhận" onclick="confirmRegistration('${r.id}')">✓</button>` : ''}
      </td>
    </tr>
  `).join('') || `<tr><td colspan="10"><div class="empty-state"><div class="empty-state-icon">📋</div><div class="empty-state-text">Không tìm thấy đơn đăng kiểm</div></div></td></tr>`;
}

function createRegistrationOrder() {
  const plate = document.getElementById('reg-plate').value.trim();
  const ownerName = document.getElementById('reg-owner-name').value.trim();
  const ownerPhone = document.getElementById('reg-owner-phone').value.trim();
  const address = document.getElementById('reg-address').value.trim();
  const center = document.getElementById('reg-center').value;
  const bookingDate = document.getElementById('reg-booking-date').value;
  const bookingTime = document.getElementById('reg-booking-time').value;
  const service = document.getElementById('reg-service').value;

  if (!plate || !ownerName || !ownerPhone || !address || !center || !bookingDate || !bookingTime) {
    alert('Vui lòng điền đầy đủ thông tin bắt buộc');
    return;
  }

  const servicePrices = { normal: 350000, express: 500000, home: 700000 };
  const centerNames = { '50-05V': 'TTĐK 50-05V (Q.3)', '50-06V': 'TTĐK 50-06V (Q.6)', '50-07V': 'TTĐK 50-07V (Thủ Đức)', '50-08V': 'TTĐK 50-08V (Bình Thạnh)' };

  const newReg = {
    id: 'REG' + String(REGISTRATIONS.length + 1).padStart(3, '0'),
    plate, ownerName, ownerPhone,
    vehicleType: document.getElementById('reg-vehicle-type').value,
    address, center, centerName: centerNames[center],
    bookingDate, bookingTime, service,
    price: servicePrices[service],
    status: 'pending',
    createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
  };

  REGISTRATIONS.unshift(newReg);
  clearRegistrationForm();
  renderRegistrations();
  alert('Tạo đơn đăng kiểm thành công!');
}

function clearRegistrationForm() {
  document.getElementById('reg-plate').value = '';
  document.getElementById('reg-owner-name').value = '';
  document.getElementById('reg-owner-phone').value = '';
  document.getElementById('reg-address').value = '';
  document.getElementById('reg-center').value = '';
  document.getElementById('reg-booking-date').value = '';
  document.getElementById('reg-notes').value = '';
}

function viewRegistration(id) {
  const r = REGISTRATIONS.find(x => x.id === id);
  if (!r) return;
  alert(`Chi tiết đơn ${id}\nBiển số: ${r.plate}\nChủ xe: ${r.ownerName}\nSĐT: ${r.ownerPhone}\nTrung tâm: ${r.centerName}\nNgày: ${r.bookingDate} ${r.bookingTime}\nGiá: ${fmt(r.price)}\nTrạng thái: ${r.status}`);
}

function confirmRegistration(id) {
  const r = REGISTRATIONS.find(x => x.id === id);
  if (r) {
    r.status = 'confirmed';
    renderRegistrations();
    alert('Xác nhận đơn thành công!');
  }
}

function renderAgentCustomers() {
  const container = document.getElementById('page-customers');
  if (container) {
    container.innerHTML = `
      <div class="stats-grid" style="margin-bottom: 20px">
        <div class="stat-card"><div class="stat-card-header"><div class="stat-card-icon accent">👥</div><span class="stat-card-label">Tổng khách hàng</span></div><div class="stat-card-value">${AGENT_CUSTOMERS.length}</div></div>
        <div class="stat-card success"><div class="stat-card-header"><div class="stat-card-icon success">🟢</div><span class="stat-card-label">Hoạt động</span></div><div class="stat-card-value">${AGENT_CUSTOMERS.filter(c => c.status === 'active').length}</div></div>
        <div class="stat-card warning"><div class="stat-card-header"><div class="stat-card-icon warning">⭐</div><span class="stat-card-label">VIP Members</span></div><div class="stat-card-value">${AGENT_CUSTOMERS.filter(c => c.level === 'VIP').length}</div></div>
      </div>
      <div class="table-container">
        <div class="table-header"><span class="table-title">Danh sách khách hàng</span>
          <div class="table-actions">
            <div class="search-box"><input type="search" placeholder="Tìm khách hàng..." id="customer-search" oninput="renderAgentCustomersList()"></div>
          </div>
        </div>
        <div class="table-wrapper">
          <table><thead><tr><th>ID</th><th>Khách hàng</th><th>Liên hệ</th><th>Booking</th><th>Tổng chi tiêu</th><th>Cấp độ</th><th>Đặt cuối</th><th>Trạng thái</th></tr></thead>
            <tbody id="customers-table-body"></tbody></table>
        </div>
      </div>
    `;
    renderAgentCustomersList();
  }
}

function renderAgentCustomersList() {
  const search = document.getElementById('customer-search')?.value?.toLowerCase();
  let customers = [...AGENT_CUSTOMERS];
  if (search) customers = customers.filter(c => c.name.toLowerCase().includes(search) || c.phone.includes(search));

  const levelColors = { VIP: '#FFB020', Gold: '#FFD700', Regular: '#94A3B8', Bronze: '#CD7F32' };
  document.getElementById('customers-table-body').innerHTML = customers.map(c => `
    <tr>
      <td><span class="text-accent fw-600">${c.id}</span></td>
      <td><div class="flex-center"><div class="driver-avatar" style="width:28px;height:28px;font-size:12px">👤</div><span class="fw-600" style="margin-left:8px">${c.name}</span></div></td>
      <td>${c.phone}</td>
      <td class="fw-600">${c.totalBookings}</td>
      <td class="fw-600 text-success">${fmt(c.totalSpent)}</td>
      <td><span class="badge" style="background:${levelColors[c.level]}20;color:${levelColors[c.level]}">${c.level}</span></td>
      <td class="text-muted">${c.lastBooking}</td>
      <td><span class="badge ${c.status === 'active' ? 'badge-active' : 'badge-inactive'}">${c.status === 'active' ? 'Hoạt động' : 'Ngừng'}</span></td>
    </tr>
  `).join('');
}

function renderReports() {
  const container = document.getElementById('page-reports');
  if (container) {
    container.innerHTML = `
      <div class="tabs" style="margin-bottom:20px">
        <button class="tab-btn active" onclick="switchReportTab('daily', this)">Hàng ngày</button>
        <button class="tab-btn" onclick="switchReportTab('weekly', this)">Hàng tuần</button>
        <button class="tab-btn" onclick="switchReportTab('monthly', this)">Hàng tháng</button>
      </div>
      <div class="report-grid">
        <div class="report-card">
          <div class="report-title">Số lượng booking</div>
          <div class="report-chart" id="report-booking-chart"></div>
          <div class="report-labels" id="report-booking-labels"></div>
        </div>
        <div class="report-card">
          <div class="report-title">Doanh thu (triệu đ)</div>
          <div class="report-chart" id="report-revenue-chart"></div>
          <div class="report-labels" id="report-revenue-labels"></div>
        </div>
        <div class="report-card">
          <div class="report-title">Khách hàng mới</div>
          <div class="report-chart" id="report-customer-chart"></div>
          <div class="report-labels" id="report-customer-labels"></div>
        </div>
      </div>
      <div class="table-container">
        <div class="table-header"><span class="table-title">Chi tiết báo cáo</span></div>
        <div class="table-wrapper">
          <table><thead><tr><th>STT</th><th>Loại</th><th>Booking</th><th>Doanh thu</th><th>Khách hàng</th><th>Tăng trưởng</th></tr></thead>
            <tbody id="report-detail-body"></tbody></table>
        </div>
      </div>
    `;
    switchReportTab('daily');
  }
}

function switchReportTab(period, btn) {
  document.querySelectorAll('.tabs .tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  const data = REPORTS[period];
  const maxBookings = Math.max(...data.bookings);
  const maxRevenue = Math.max(...data.revenue);
  const maxCustomers = Math.max(...data.customers);

  document.getElementById('report-booking-chart').innerHTML = data.bookings.map(v => `<div class="report-bar" style="height:${(v/maxBookings)*100}%" data-value="${v}"></div>`).join('');
  document.getElementById('report-booking-labels').innerHTML = data.labels.map(l => `<span>${l}</span>`).join('');

  document.getElementById('report-revenue-chart').innerHTML = data.revenue.map(v => `<div class="report-bar" style="height:${(v/maxRevenue)*100}%" data-value="${v/1000000}M"></div>`).join('');
  document.getElementById('report-revenue-labels').innerHTML = data.labels.map(l => `<span>${l}</span>`).join('');

  document.getElementById('report-customer-chart').innerHTML = data.customers.map(v => `<div class="report-bar" style="height:${(v/maxCustomers)*100}%" data-value="${v}"></div>`).join('');
  document.getElementById('report-customer-labels').innerHTML = data.labels.map(l => `<span>${l}</span>`).join('');

  const totals = {
    bookings: data.bookings.reduce((a,b) => a+b, 0),
    revenue: data.revenue.reduce((a,b) => a+b, 0),
    customers: data.customers.reduce((a,b) => a+b, 0)
  };

  document.getElementById('report-detail-body').innerHTML = `
    <tr>
      <td>1</td>
      <td class="fw-600">Tổng cộng</td>
      <td class="fw-600">${totals.bookings.toLocaleString()}</td>
      <td class="fw-600 text-success">${fmt(totals.revenue)}</td>
      <td class="fw-600">${totals.customers}</td>
      <td><span class="badge badge-completed">+12.5%</span></td>
    </tr>
  `;
}

// ============================================
// INTERCITY BOOKING FUNCTIONS
// ============================================
function swapRoute() {
  const origin = document.getElementById('intercity-origin');
  const destination = document.getElementById('intercity-destination');
  const temp = origin.value;
  origin.value = destination.value;
  destination.value = temp;
}

function searchIntercityTrips() {
  const origin = document.getElementById('intercity-origin').value;
  const destinationSelect = document.getElementById('intercity-destination');
  const destinationValue = destinationSelect.value;
  const destinationText = destinationSelect.options[destinationSelect.selectedIndex].text;
  const date = document.getElementById('intercity-date').value;
  const passengers = document.getElementById('intercity-passengers').value;

  if (!origin || !destinationValue) {
    alert('Vui lòng chọn điểm đi và điểm đến');
    return;
  }

  // Map dropdown values to route destinations
  const destMap = {
    'DL': 'Đà Lạt', 'CT': 'Cần Thơ', 'NT': 'Nha Trang', 'VT': 'Vũng Tàu',
    'PT': 'Phan Thiết', 'DN': 'Đà Nẵng', 'HN': 'Hà Nội', 'HP': 'Hải Phòng', 'HA': 'Hội An'
  };

  // Filter trips based on selection
  const trips = INTERCITY_TRIPS.filter(t => {
    const route = INTERCITY_ROUTES.find(r => r.id === t.routeId);
    if (!route) return false;
    if (route.origin !== origin) return false;
    // Check destination by value or text
    const targetDest = destMap[destinationValue] || destinationText;
    if (route.destination !== targetDest) return false;
    if (date && t.date !== date) return false;
    return t.status === 'available';
  });

  if (trips.length === 0) {
    document.getElementById('intercity-results').innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🔍</div>
        <div class="empty-state-text">Không tìm thấy chuyến nào phù hợp</div>
      </div>
    `;
    return;
  }

  document.getElementById('intercity-results').innerHTML = trips.map(t => {
    const sold = t.seatsTotal - t.seatsAvailable;
    const percent = Math.round((sold / t.seatsTotal) * 100);
    const isFull = t.seatsAvailable === 0;
    const bgColor = percent >= 90 ? 'var(--danger-bg)' : percent >= 70 ? 'var(--warning-bg)' : 'var(--success-bg)';
    const textColor = percent >= 90 ? 'var(--danger)' : percent >= 70 ? 'var(--warning)' : 'var(--success)';

    return `
    <div class="trip-card" onclick="showTripDetail('${t.id}')">
      <div class="trip-header">
        <span class="trip-operator">${t.operatorName}</span>
        <span class="trip-price">${fmt(t.price)}</span>
      </div>
      <div class="trip-times">
        <span class="trip-time">${t.departureTime}</span>
        <span class="trip-duration">${t.duration}</span>
        <span class="trip-time">${t.arrivalTime}</span>
      </div>
      <div class="trip-info" style="margin-top:12px">
        <span>${t.vehicleType}</span>
        <span style="padding:4px 8px;border-radius:4px;background:${bgColor};color:${textColor};font-weight:600">
          ${sold} / ${t.seatsTotal} vé đã bán (${percent}%)
        </span>
      </div>
      ${isFull ? '<div style="color:var(--danger);font-weight:600;margin-top:8px">⚠️ Hết vé</div>' : ''}
    </div>
  `}).join('');
}

function showTripDetail(tripId) {
  const trip = INTERCITY_TRIPS.find(t => t.id === tripId);
  if (!trip) return;

  const passengers = document.getElementById('intercity-passengers').value;
  const sold = trip.seatsTotal - trip.seatsAvailable;
  const total = trip.price * parseInt(passengers);

  document.getElementById('intercity-results').innerHTML = `
    <div class="trip-card selected">
      <div class="trip-header">
        <span class="trip-operator">${trip.operatorName}</span>
        <span class="trip-price">${fmt(trip.price)}</span>
      </div>
      <div class="trip-times">
        <span class="trip-time">${trip.departureTime}</span>
        <span class="trip-duration">${trip.duration}</span>
        <span class="trip-time">${trip.arrivalTime}</span>
      </div>
      <div class="trip-info" style="margin-top:12px">
        <span>${trip.vehicleType}</span>
        <span>${sold}/${trip.seatsTotal} vé đã bán</span>
      </div>
    </div>
    <div style="background:var(--bg-card);border:1px solid var(--border-color);border-radius:var(--radius-lg);padding:20px;margin-top:16px">
      <h4 style="margin-bottom:16px">Đặt vé</h4>
      <div class="form-grid">
        <div class="input-group"><label>Số khách</label><input type="number" id="booking-passengers" value="${passengers}" min="1" max="${trip.seatsAvailable}" onchange="updateBookingTotal('${trip.id}', this.value)"></div>
        <div class="input-group"><label>Tổng tiền</label><div style="font-size:24px;font-weight:700;color:var(--success);padding:8px 0" id="booking-total">${fmt(total)}</div></div>
        <div class="input-group full-width"><label>Họ tên khách</label><input type="text" id="customer-name" placeholder="Nguyễn Văn A"></div>
        <div class="input-group full-width"><label>Số điện thoại</label><input type="text" id="customer-phone" placeholder="090xxxxxxx"></div>
      </div>
      <button class="btn btn-primary" style="width:100%;margin-top:16px" onclick="createIntercityBooking('${trip.id}')">Tạo đơn vé</button>
      <button class="btn btn-outline" style="width:100%;margin-top:8px" onclick="backToTripList()">Quay lại</button>
    </div>
  `;
}

function backToTripList() {
  renderIntercityBooking();
}

function updateBookingTotal(tripId, passengers) {
  const trip = INTERCITY_TRIPS.find(t => t.id === tripId);
  if (!trip) return;
  const total = trip.price * parseInt(passengers);
  document.getElementById('booking-total').textContent = fmt(total);
}

function createIntercityBooking(tripId) {
  const trip = INTERCITY_TRIPS.find(t => t.id === tripId);
  if (!trip) return;

  const passengers = parseInt(document.getElementById('booking-passengers').value);
  const customerName = document.getElementById('customer-name').value;
  const customerPhone = document.getElementById('customer-phone').value;

  if (!customerName || !customerPhone) {
    alert('Vui lòng nhập thông tin khách hàng!');
    return;
  }

  if (passengers > trip.seatsAvailable) {
    alert('Số lượng vé không đủ!');
    return;
  }

  // Create booking
  const newBooking = {
    id: 'BK' + String(BOOKINGS.length + 1).padStart(3, '0'),
    bookingCode: 'RO-' + new Date().toISOString().slice(2,10).replace(/-/g,'') + '-' + String(BOOKINGS.length + 1).padStart(3, '0'),
    bookingType: 'INTERCITY',
    bookingStatus: 'PENDING_CONFIRMATION',
    paymentStatus: 'PENDING',
    fulfillmentStatus: null,
    customerId: 'KH00' + (CUSTOMERS.length + 1),
    agentId: currentUser?.id || 'USR003',
    driverId: null,
    pickup: 'BX ' + trip.operatorName,
    dropoff: document.getElementById('intercity-destination').value,
    routeId: trip.routeId,
    scheduleId: trip.id,
    seatNumbers: [],
    passengerSnapshot: [{ name: customerName, phone: customerPhone }],
    fareSnapshot: trip.price * passengers,
    distance: INTERCITY_ROUTES.find(r => r.id === trip.routeId)?.distance || 0,
    paymentReference: null,
    fulfillmentTaskId: null,
    createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
    updatedAt: new Date().toISOString().replace('T', ' ').slice(0, 16)
  };

  // Add customer if not exists
  const existingCustomer = CUSTOMERS.find(c => c.phone === customerPhone);
  if (!existingCustomer) {
    CUSTOMERS.push({
      id: newBooking.customerId,
      name: customerName,
      phone: customerPhone,
      email: '',
      totalBookings: 1,
      status: 'active'
    });
  }

  BOOKINGS.push(newBooking);

  // Update available seats
  trip.seatsAvailable -= passengers;

  alert('Tạo đơn vé thành công! Mã booking: ' + newBooking.bookingCode);
  searchIntercityTrips();
}
